<?php

$db_data=array(
    'nsy_db'=>array(

        'dsn'=>'mysql:host=10.1.9.51;dbname=nsy_db',

        'username'=>'pmcx',

        'password'=>'2xZenvOTGzCn'

    ),
    'nswyun'=>array(

        'dsn'=>'mysql:host=192.168.31.201;dbname=nswyun',

        'username'=>'nswyun_f',

        'password'=>'T8OfyVvLX!gN'
    ),


);
return  $db_data;
